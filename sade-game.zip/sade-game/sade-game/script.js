let i = "";
let k = "";
let can = ""

let sade = document.getElementById("sade")
let cetin = document.getElementById("cetin")
let sp = document.getElementById("sadespan");

function gonder1() {
    sp.innerHTML = "Sade variant:</br> 1-den -10-a qeder reqem sec </br> 3 sansin var"
    i = sade=document.getElementById("sade").value;
    k = Math.floor(Math.random() * 10);

    console.log(i);
}



function gonder2() {
    sp.innerHTML = "Cetin variant: </br> 1-den -20-a qeder reqem sec </br> 5 sansin var"
    i = document.getElementById("cetin").value;
    k = Math.floor(Math.random() * 20);
 
}



function cvb() {
    can=--i
    
    let cvb = document.getElementById("input").value;
    if (cvb > k) { sp = document.getElementById("sadespan").innerHTML = `Daxil edilen eded boyukdur  ${i} cehd qaldi`}
    else if (cvb < k) { sp = document.getElementById("sadespan").innerHTML = `Daxil edilen eded kicikdir ${i} cehd qaldi` }
    else if (cvb == k) { sp = document.getElementById("sadespan").innerHTML = `Tebrikler siz qazandiniz` }
    else if (i == 0) { sp.document.getElementById("sadespan").innerHTML = "Teesufki siz uduzdunuz" }

}


console.log(cvb);

